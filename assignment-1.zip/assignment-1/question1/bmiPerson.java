package question1;
import java.util.Scanner;

public class bmiPerson {

	public static void main(String[] args) {
		// in this program we are going to calculate the BMI of a person
		// give their weight, height and name
		
		System.out.println("Hello!!, we are going to calculate your BMI please enter the following inputs: ");
		
		// name 
		System.out.print("Enter your name: ");
		Scanner input = new Scanner(System.in);
		String name = input.next();		// user inputs their name
		
		// heigth
		System.out.print("Enter your height(in meters): ");
		double heigth = input.nextDouble();		// user inputs their heigth
		
		// weigth
		System.out.print("Enter your weigth(in kgs): ");
		double weigth = input.nextDouble();		// user inputs their width
		
		// calculating the BMI
		double kg2 = Math.pow(weigth, 2);
		double bmi = kg2 / heigth;
		System.out.print(name);
		System.out.print(" your bmi is ");
		System.out.format("%.2f", bmi);
	}

}
