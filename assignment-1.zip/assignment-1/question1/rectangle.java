package question1;
import java.util.Scanner;

public class rectangle {

	public static void main(String[] args) {
		// in this program we are going to find the area of a rectangle
		// and also find its perimeter
		
		System.out.println("We are going to find the perimeter and area of a rectangle");
		
		Scanner input = new Scanner(System.in);
		// inputing width
		System.out.print("Width: ");
		double width = input.nextDouble();	// user inputs the width
		
		// input length
		System.out.print("Length: ");
		double length = input.nextDouble();	// user inputs the length
		
		// perimeter of the triangle (L + W)*2
		double perimeter = (width + length) * 2;	// calculate the perimeter
		System.out.print("Perimeter of the rectangle is ");
		System.out.format("%.2f", perimeter);
		
		// area of the triangle (length * width)
		double area = (width * length);				// calculate the area
		System.out.print("Area of the rectangle is ");
		System.out.format("%.2f", area);

	}

}
